<?php
/**
 * [PROWEBBER.ru - 2019]
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 *
 *
 * @copyright       [PHPFOX_COPYRIGHT]
 * @author          phpFox LLC
 * @package         Phpfox_Service
 * @version         $Id: callback.class.php 7255 2014-04-07 17:39:00Z phpFox $
 */
class Phpfox_Pages_Callback extends Phpfox_Service
{
    /**
     * Class constructor
     */
    public function __construct()
    {
        // add this file again to fix upgrade from 4.5.3 => 4.7.x
    }
}

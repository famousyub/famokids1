<?php

defined('PHPFOX') or exit('NO DICE!');

/**
 * Class Phpfox_Verify_Driver_Abstract
 */
abstract class Phpfox_Verify_Driver_Abstract implements Phpfox_Verify_Driver_Interface
{

}
<?php

$this->_upgradeDatabase('3.1.0beta1');

$bCompleted = true;

?>
<?php
$this->_upgradeDatabase('3.9.0');
$bCompleted = true;
?>

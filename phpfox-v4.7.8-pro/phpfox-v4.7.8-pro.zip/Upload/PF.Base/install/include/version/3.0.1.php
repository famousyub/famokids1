<?php

$this->_upgradeDatabase('3.0.1');

$bCompleted = true;

?>
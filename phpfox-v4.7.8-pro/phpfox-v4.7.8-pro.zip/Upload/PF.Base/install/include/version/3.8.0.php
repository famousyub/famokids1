<?php
$this->_upgradeDatabase('3.8.0');
$bCompleted = true;
?>

<?php

$this->_upgradeDatabase('3.7.0beta1');
$bCompleted = true;

?>
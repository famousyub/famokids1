<?php

$this->_upgradeDatabase('3.7.1');
$bCompleted = true;

?>
<?php

$this->_upgradeDatabase('3.7.0');
$bCompleted = true;

?>
<?php

$this->_upgradeDatabase('3.6.0beta3');
$bCompleted = true;

?>
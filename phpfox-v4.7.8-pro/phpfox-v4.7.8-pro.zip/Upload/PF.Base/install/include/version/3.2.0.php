<?php

$this->_upgradeDatabase('3.2.0');

$bCompleted = true;

?>
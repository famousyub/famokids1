<?php

$this->_upgradeDatabase('3.0.0rc3');

$bCompleted = true;

?>
<?php

return function(Phpfox_Installer $Installer) {
	
};
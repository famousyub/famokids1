<?php

$this->_upgradeDatabase('3.4.0rc1');

$bCompleted = true;

?>
<?php defined("PHPFOX") or die("Access denied"); return array (
  'theme-material' => 
  array (
    'type' => 'theme',
    'target' => 'PF.Site/flavors/material',
    'filename' => 'theme-material.zip',
    'apps_id' => NULL,
    'apps_dir' => NULL,
    'apps_name' => NULL,
    'apps_version' => '4.7.8',
  ),
  'photos' => 
  array (
    'type' => 'app',
    'target' => 'PF.Site/Apps/core-photos',
    'filename' => 'core-photos.zip',
    'apps_id' => 'Core_Photos',
    'apps_dir' => 'core-photos',
    'apps_name' => 'Photos',
    'apps_version' => '4.7.7',
  ),
);
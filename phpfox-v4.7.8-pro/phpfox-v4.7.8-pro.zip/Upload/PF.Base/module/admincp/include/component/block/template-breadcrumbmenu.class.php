<?php
/**
 * @author  phpFox LLC
 * @license phpfox.com
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 * Class Admincp_Component_Block_Stat
 */
class Admincp_Component_Block_Template_Breadcrumbmenu extends Phpfox_Component
{
    public function process()
    {
    }
}
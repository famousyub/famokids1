<?php
/**
 * [PROWEBBER.ru - 2019]
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 * 
 * 
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		phpFox LLC
 * @package  		Module_Admincp
 * @version 		$Id: phpfox.class.php 4623 2012-09-12 08:28:51Z phpFox LLC $
 */
class Module_Admincp 
{	
	public static $aTables = array(
		'admincp_privacy'		
	);
}
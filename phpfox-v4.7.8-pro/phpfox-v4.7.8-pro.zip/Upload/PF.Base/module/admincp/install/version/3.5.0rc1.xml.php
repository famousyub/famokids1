<upgrade>
	<hooks>
		<hook>
			<module_id>admincp</module_id>
			<hook_type>controller</hook_type>
			<module>admincp</module>
			<call_name>admincp.component_controller_limit_clean</call_name>
			<added>1361175548</added>
			<version_id>3.5.0rc1</version_id>
			<value />
		</hook>
		<hook>
			<module_id>admincp</module_id>
			<hook_type>component</hook_type>
			<module>admincp</module>
			<call_name>admincp.component_block_oncloud_clean</call_name>
			<added>1361175548</added>
			<version_id>3.5.0rc1</version_id>
			<value />
		</hook>
	</hooks>
</upgrade>
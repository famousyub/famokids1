INSTALLATION:

1. Extract phpFox-v4.7.8 Pro & upload to your server.
2. Start the normal installation process.
3. Enter License ID & License Key - "ProWebber".
4. Installation Done.

INSTALLATION APPS:

1. Go to Admincp - Apps.
2. Import Module. 

DONE!

//////////////Downloaded from prowebber.ru
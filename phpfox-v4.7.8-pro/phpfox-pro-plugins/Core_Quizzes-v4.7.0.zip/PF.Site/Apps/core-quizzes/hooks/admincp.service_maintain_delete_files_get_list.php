<?php
$aPluginFiles[] = 'PF.Base/module/quiz/';
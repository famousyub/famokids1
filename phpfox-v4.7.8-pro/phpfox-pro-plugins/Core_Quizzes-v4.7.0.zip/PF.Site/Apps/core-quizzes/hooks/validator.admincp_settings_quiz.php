<?php

$aValidation = [
    'default_answers_count' => [
        'def' => 'int:required',
        'min' => '2',
        'title' => _p('"How Many Answers Per Default" must be greater than 1'),
    ],
];

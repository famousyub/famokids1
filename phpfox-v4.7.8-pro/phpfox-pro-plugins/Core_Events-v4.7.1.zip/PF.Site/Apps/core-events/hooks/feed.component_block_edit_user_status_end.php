<?php
if (!empty($module) && $module == 'event') {
    $this->template()->assign(['bLoadTagFriends' => false]);
}

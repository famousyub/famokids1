<?php
$aPluginFiles[] = 'PF.Base/module/event/';
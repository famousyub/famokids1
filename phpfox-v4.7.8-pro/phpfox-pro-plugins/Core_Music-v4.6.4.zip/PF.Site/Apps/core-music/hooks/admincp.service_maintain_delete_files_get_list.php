<?php
$aPluginFiles[] = 'PF.Base/module/music/';
$aPluginFiles[] = 'PF.Site/Apps/core-music/assets/autoload.css';
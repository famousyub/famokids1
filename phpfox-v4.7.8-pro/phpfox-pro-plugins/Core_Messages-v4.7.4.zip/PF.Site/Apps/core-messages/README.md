# Messages

## App Info

- `App name`: Messages
- `Version`: 4.7.4
- `Store link`: https://store.phpfox.com/product/
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install Messages app:

1. Install the Messages app from the store.

2. Remove files no longer used (at Admin Panel > Maintenance > Remove files no longer used).

3. Clear `Cache` and `Rebuild Core Theme` on your site.

Congratulation! You have completed the installation process.

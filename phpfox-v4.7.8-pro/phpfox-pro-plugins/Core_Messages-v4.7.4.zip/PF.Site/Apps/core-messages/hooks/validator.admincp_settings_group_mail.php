<?php
$aValidation['mail_from_name'] = [
    'def' => 'required',
    'title' => _p('"Name" is required')
];
$aValidation['email_from_email'] = [
    'def' => 'required',
    'title' => _p('"From" is required')
];

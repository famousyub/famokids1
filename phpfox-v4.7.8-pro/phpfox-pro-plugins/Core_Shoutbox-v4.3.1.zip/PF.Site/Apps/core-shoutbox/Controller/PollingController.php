<?php

namespace Apps\phpFox_Shoutbox\Controller;

define('PHPFOX_AJAX_CALL_PROCESS', true);

use Phpfox;
use Apps\phpFox_Shoutbox\Service\Shoutbox as sb;

class PollingController extends \Admincp_Component_Controller_App_Index
{
    public function process()
    {
        if (!Phpfox::getUserParam('shoutbox.shoutbox_can_view')) {
            exit (json_encode([
                'error' => _p('cannot_display_due_to_privacy')
            ]));
        }

        $type = Phpfox::getLib('request')->get('type');
        $parent_module_id = Phpfox::getLib('request')->get('parent_module_id');
        $parent_item_id = Phpfox::getLib('request')->get('parent_item_id');

        if($parent_module_id == 'pages') {
            //In pages, check can view shoutbox
            if (!Phpfox::getService('pages')->hasPerm($parent_item_id, 'shoutbox.view_shoutbox')) {
                exit (json_encode([
                    'error' => _p('cannot_display_due_to_privacy')
                ]));
            }
        }
        elseif ($parent_module_id == 'groups') {
            //In groups, check can view shoutbox
            if (!Phpfox::getService('groups')->hasPerm($parent_item_id, 'shoutbox.view_shoutbox')) {
                exit (json_encode([
                    'error' => _p('cannot_display_due_to_privacy')
                ]));
            }
        }

        if ($type == 'pull') {
            $aJsonData = [];
            $iLastShoutboxId = Phpfox::getLib('request')->get('last', 0);
            if ($iLastShoutboxId == 0) {
                $iLastShoutboxId = Phpfox::getCookie('last_shoutbox_id');
            }
            $aData = sb::get()->check($iLastShoutboxId, $parent_module_id, $parent_item_id);
            if (isset($aData['shoutbox_id'])) {
                $aJsonData = [
                    'shoutbox_id' => $aData['shoutbox_id'],
                    'text' => $aData['text'],
                    'user_avatar' => Phpfox::getLib('phpfox.image.helper')->display([
                        'user' => $aData,
                        'suffix' => '_50_square',
                        'width' => 40,
                        'height' => 40
                    ]),
                    'timestamp' => isset($aData['timestamp']) ? $aData['timestamp'] : 0,
                    'parsed_time' => isset($aData['timestamp']) ? Phpfox::getLib('date')->convertTime($aData['timestamp']) : '',
                    'user_type' => Phpfox::isAdmin() ? 'a' : 'u',
                    'user_profile_link' => Phpfox::getLib('url')->makeUrl($aData['user_name']),
                    'user_full_name' => $aData['full_name'],
                    'can_edit' => $aData['canEdit'],
                    'edit_title' => _p('shoutbox_edit_message'),
                    'hover_title' => _p('edit'),
                    'total_like' => $aData['total_like'],
                    'like_title' => _p('like'),
                    'likes_title' => _p('likes'),
                    'quote_hover_title' => _p('quote'),
                    'dismiss_hover_title' => _p('delete'),
                    'can_delete' => $aData['canDeleteOwn'] || $aData['canDeleteAll'],
                    'is_edited' => $aData['is_edited'],
                    'edited_title' => _p('shoutbox_edited'),
                    'unlike_title' => _p('unlike'),
                    'can_quote' => Phpfox::isUser(),
                    'can_show_action' => $aData['canShowAction'],
                ];
            }

            if (function_exists('ob_get_level')) {
                while (ob_get_level()) {
                    ob_get_clean();
                }
            }
            if (count($aJsonData)) {
                echo json_encode($aJsonData);
            } else {
                echo json_encode(['empty' => true]);
            }
        } elseif ($type == 'push') {
            $aVals = [
                'parent_module_id' => $parent_module_id,
                'parent_item_id' => $parent_item_id,
                'text' => Phpfox::getLib('request')->get('text'),
            ];
            $iShoutboxId = sb::process()->add($aVals);
            if (function_exists('ob_get_level')) {
                while (ob_get_level()) {
                    ob_get_clean();
                }
            }
            if (is_int($iShoutboxId)) {
                $aPushShoutBox = sb::get()->getShoutbox($iShoutboxId, true);
                exit (json_encode([
                    'shoutbox_id' => $iShoutboxId,
                    'text' => $aPushShoutBox['text'],
                    'user_profile_link' => Phpfox::getLib('url')->makeUrl($aPushShoutBox['quoted_user_name']),
                    'time_stamp' => $aPushShoutBox['timestamp'],
                    'parsed_time' => Phpfox::getLib('date')->convertTime($aPushShoutBox['timestamp']),
                    'can_edit' => $aPushShoutBox['canEdit'],
                    'can_delete' => $aPushShoutBox['canDeleteOwn'] || $aPushShoutBox['canDeleteAll'],
                    'edit_title' => _p('shoutbox_edit_message'),
                    'hover_title' => _p('edit'),
                    'full_name' => $aPushShoutBox['full_name'],
                    'like_title' => _p('like'),
                    'quote_hover_title' => _p('quote'),
                    'dismiss_hover_title' => _p('delete'),
                ]));
            } else {
                exit (json_encode([
                    'error' => $iShoutboxId
                ]));
            }
        } elseif ($type == 'more') {
            $iLastShoutboxId = Phpfox::getLib('request')->get('last');
            $aShoutboxes = sb::get()->getLast($iLastShoutboxId, $parent_module_id, $parent_item_id);
            $aJsonData = [];
            foreach ($aShoutboxes as $aShoutbox) {
                $aJson = [];
                if (isset($aShoutbox['shoutbox_id'])) {
                    $aJson = [
                        'shoutbox_id' => $aShoutbox['shoutbox_id'],
                        'text' => $aShoutbox['text'],
                        'user_avatar' =>  Phpfox::getLib('phpfox.image.helper')->display([
                            'user' => $aShoutbox,
                            'suffix' => '_50_square',
                            'width' => 40,
                            'height' => 40
                        ]),
                        'timestamp' => isset($aShoutbox['timestamp']) ? $aShoutbox['timestamp'] : 0,
                        'parsed_time' => isset($aShoutbox['timestamp']) ? Phpfox::getLib('date')->convertTime($aShoutbox['timestamp']) : '',
                        'user_profile_link' => Phpfox::getLib('url')->makeUrl($aShoutbox['user_name']),
                        'user_full_name' => $aShoutbox['full_name'],
                        'user_type' => Phpfox::isAdmin() ? 'a' : 'u',
                        'type' => Phpfox::getUserId() == $aShoutbox['user_id'] ? 's' : 'r',
                        'can_edit' => $aShoutbox['canEdit'],
                        'like_title' => _p('like'),
                        'is_liked' => $aShoutbox['is_liked'],
                        'total_like' => $aShoutbox['total_like'],
                        'quoted_text' => Phpfox::getLib('parse.output')->parse($aShoutbox['quoted_text']),
                        'quoted_full_name' => $aShoutbox['quoted_full_name'],
                        'quoted_user_name' => $aShoutbox['quoted_user_name'],
                        'quote_hover_title' => _p('quote'),
                        'dismiss_hover_title' => _p('delete'),
                        'hover_title' => _p('edit'),
                        'can_delete' => $aShoutbox['canDeleteOwn'] || $aShoutbox['canDeleteAll'],
                        'is_edited' => $aShoutbox['is_edited'],
                        'edited_title' => _p('shoutbox_edited'),
                        'likes_title' => _p('likes'),
                        'unlike_title' => _p('unlike'),
                        'can_quote' => Phpfox::isUser(),
                        'can_show_action' => $aShoutbox['canShowAction'],
                    ];
                }
                $aJsonData[] = $aJson;
            }

            if (function_exists('ob_get_level')) {
                while (ob_get_level()) {
                    ob_get_clean();
                }
            }
            if (count($aJsonData)) {
                echo json_encode($aJsonData);
            } else {
                echo json_encode(['empty' => true]);
            }
        }
        exit();
    }
}
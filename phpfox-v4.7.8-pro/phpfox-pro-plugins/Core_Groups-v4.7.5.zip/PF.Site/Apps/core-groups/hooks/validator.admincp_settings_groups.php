<?php
$aValidation = [
    'groups_limit_per_category' => [
        'title' => _p('validator_groups_limit_per_category'),
        'def' => 'int:required',
        'min' => 0
    ],
];

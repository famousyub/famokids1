<?php
$aPhotos['marketplace_default_photo'] = [
    'title' => _p('marketplace_default_photo'),
    'value' => $flavor->default_photo('marketplace_default_photo', true),
];
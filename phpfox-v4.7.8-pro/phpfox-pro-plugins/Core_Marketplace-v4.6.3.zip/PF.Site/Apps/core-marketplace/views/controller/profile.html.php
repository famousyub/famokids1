<?php 

 
defined('PHPFOX') or exit('NO DICE!'); 

?>
{template file='marketplace.controller.index'}
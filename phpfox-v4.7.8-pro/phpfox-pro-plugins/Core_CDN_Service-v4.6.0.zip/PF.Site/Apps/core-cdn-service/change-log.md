# CDN Service :: Change Log #

## Version 4.6.0

### Information

- **Release Date:** January 09, 2018
- **Best Compatibility:** phpFox 4.6.0 or later

### Improvements

- Check compatible with phpFox core and porting apps 4.6.0.

### Changed Files

- Install.php

## Version 4.5.3 ##

### Information ###

- **Release Date:** September 18, 2017
- **Best Compatibility:** phpFox 4.5.3 or higher


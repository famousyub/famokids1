<?php

$aExcludeBundles[] = 'im-libraries.min.js';
<?php
$this->setHeader([
    'im-libraries.min.js' => 'app_core-im',
]);

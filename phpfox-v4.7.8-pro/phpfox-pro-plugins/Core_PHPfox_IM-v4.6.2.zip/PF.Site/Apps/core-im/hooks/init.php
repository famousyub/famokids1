<?php
// THIS HOOK USE FOR CHECKING HOSTING SERVICE

$package_id = 0;
$cache = cache('im_hosted');
if (request()->get('im-reset-cache')) {
    $cache->del();
}

if (!($host = $cache->get()) || defined('PF_IM_DEBUG_URL')) {
    if (!defined('PHPFOX_TRIAL_MODE') and defined('PHPFOX_LICENSE_ID') and PHPFOX_LICENSE_ID) {
        $home = new Core\Home(PHPFOX_LICENSE_ID, PHPFOX_LICENSE_KEY);
        $hosted = $home->im();
        if (isset($hosted->license_id)) {
            $package_id = $hosted->package_id;
        }
    }

    $cache->set('im_hosted', [
        'package_id' => $package_id
    ]);

    $host = cache('im_hosted')->get();
}



if (!empty($host['package_id']) && request()->segment(2) != 'hosting') {
    if (!defined('PF_IM_PACKAGE_ID')) {
        define('PF_IM_PACKAGE_ID', $host['package_id']);
    }

    if (empty(storage()->get('im/host/status')->value) || storage()->get('im/host/status')->value == 'on') {
        if (PF_IM_PACKAGE_ID) {
            $url = (defined('PF_IM_DEBUG_URL') ? PF_IM_DEBUG_URL : 'https://im-node.phpfox.com/');
            setting()->set('pf_im_node_server', $url);

            $firebaseUpdated  = cache('im/host/firebase_updated')->get(null, 60);

            if(Phpfox::isAppActive('Core_MobileApi') && !$firebaseUpdated){
                $firebaseSettings  = [
                    'serverKey' => Phpfox::getParam('mobile.mobile_firebase_server_key'),
                    'senderId'  => Phpfox::getParam('mobile.mobile_firebase_sender_id'),
                    'host'=> Phpfox::getParam('core.host')
                ];

                $ch = curl_init('https://im-node.phpfox.com/socket.io/?'. http_build_query($firebaseSettings));

                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 1000);

                curl_exec($ch);
                curl_close($ch);

                $firebaseUpdated  = cache()->set('im/host/firebase_updated', true);
            }

            $aTokenData = cache('im_host_expired')->get(null, 600);
            if (isset($aTokenData) && ($aTokenData['expired'] > time())) {
                $token = $aTokenData['token'];
            } else {
                $token = (array) (new Core\Home(PHPFOX_LICENSE_ID, PHPFOX_LICENSE_KEY))->im_token();
                storage()->update('im_host_expired', !isset($token->token));
                cache()->set('im_host_token', [
                    'token' => $token,
                    'expired' => time() + 86400,
                    ]);
                $cache->del();
            }
            $token = (object)$token;

            define('PHPFOX_IM_TOKEN', isset($token->token) ? $token->token : 'failed');
            if (isset($token->token)) {
                storage()->del('im/host/status');
                storage()->set('im/host/status', 'on');
            }
        }
    }
}

<?php
$aPluginFiles[] = 'PF.Base/module/user/include/component/block/purchasepoints.class.php';
$aPluginFiles[] = 'PF.Base/module/user/template/default/block/purchasepoints.html.php';
$aPluginFiles[] = 'PF.Site/Apps/core-activity-points/Block/InformationBlock.php';
$aPluginFiles[] = 'PF.Site/Apps/core-activity-points/views/block/information.html.php';
<?php
defined('PHPFOX') or exit('NO DICE!');
?>
{module name='api.gateway.form' bIsThickBox=$bIsThickBox}

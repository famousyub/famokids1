<?php 
defined('PHPFOX') or exit('NO DICE!');
?>
<div class="pages-category">
    {template file='core.block.category'}
</div>
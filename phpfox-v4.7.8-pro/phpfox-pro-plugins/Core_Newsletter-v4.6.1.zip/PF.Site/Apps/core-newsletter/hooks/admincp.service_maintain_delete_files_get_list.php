<?php
$aPluginFiles[] = 'PF.Base/module/newsletter/';

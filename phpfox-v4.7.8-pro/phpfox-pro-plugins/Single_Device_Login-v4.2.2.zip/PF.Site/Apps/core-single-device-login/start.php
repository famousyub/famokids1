<?php

namespace Apps\phpFox_Single_Device_Login;


\Phpfox_Module::instance()
    ->addServiceNames([
        'login-history.device' => '\Apps\phpFox_Single_Device_Login\Service\Device',
        'login-history' => '\Apps\phpFox_Single_Device_Login\Service\Single',
        'login-history.hash' => '\Apps\phpFox_Single_Device_Login\Service\Hash',
        'login-history.callback' => '\Apps\phpFox_Single_Device_Login\Service\Callback'
    ])
    ->addComponentNames('controller', [
        'login-history.index' => Controller\HistoryController::class,
        'login-history.blocked-ips' => Controller\BlockedIPsController::class,
        'login-history.blocked-devices' => Controller\BlockedDevicesController::class,
        'login-history.trusted-ips' => Controller\TrustedIPsController::class,
    ])
    ->addComponentNames('block', [
    ])
    ->addTemplateDirs([
        'login-history' => PHPFOX_DIR_SITE_APPS . 'core-single-device-login' . PHPFOX_DS . 'views',
    ])
    ->addComponentNames('ajax', [
        'login-history.ajax' => '\Apps\phpFox_Single_Device_Login\Ajax\Ajax',
    ])
    ->addAliasNames('login-history', 'phpFox_Single_Device_Login');


group('/login-history', function () {
    route('', 'login-history.index');
    route('/blocked-ips', 'login-history.blocked-ips');
    route('/blocked-devices', 'login-history.blocked-devices');
    route('/trusted-ips', 'login-history.trusted-ips');
});

# Single Device Login :: Change Log

## Version 4.2.0

### Information

- **Release Date:** April 23, 2018
- **Best Compatibility:** phpFox >= 4.6.1

### New Features

- Allow users can trust Device.
- Allow users can trust/block IP.

### Improvements

- Update algorithm to check unique device.
- Support actions on warning message.
- Support link to view login session in notification email.
- Update layout.

### Fixed Bugs

- User Group setting doesn't affect.
- Warning Popup stills show after logging out.
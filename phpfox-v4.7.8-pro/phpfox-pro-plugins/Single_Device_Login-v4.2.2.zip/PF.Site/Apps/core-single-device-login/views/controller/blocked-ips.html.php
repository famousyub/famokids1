    {if $aBlockedIps}
    <div class="table-responsive single-device-table">
        <table class="table">
        <thead>
        <tr>
            <th class="w20 table-th-checkbox">
                <input class="last_clicked_button" data-cmd="core.toggle_check_all" type="checkbox" />
            </th>
            <th {table_sort class="w60 centered" current=$current asc="ip_asc" desc="ip_desc" query="sort"}>
                {_p var='ip_address'}
            </th>
            <th {table_sort class="centered" current=$current asc="recent" desc="latest" query="sort"}>
                {_p var='time_blocked'}
            </th>
            <th>
                {_p var='action'}
            </th>
        </tr>
        </thead>
        <tbody>
        {foreach from=$aBlockedIps name=aBlockedIps key=iKey item=aBlockedIp}
        <tr id="row_ip_{$aBlockedIp.blocked_id}">
            <td class="table-td-checkbox">
                <div class="moderation_row">
                    <label class="item-checkbox">
                        <input type="checkbox" class="js_global_item_moderate" name="item_moderate[]" value="{$aBlockedIp.blocked_id}" id="check{$aBlockedIp.blocked_id}" />
                        <i class="ico ico-square-o"></i>
                    </label>
                </div>
            </td>
            <td>{$aBlockedIp.blocked_info}</td>
            <td>{$aBlockedIp.timestamp|convert_time:'core.global_update_time'}</td>
            <td>
                <ul class="single-action">
                    <li><a href="javascript:void(0);" onclick="$.ajaxCall('login-history.trustIp', 'hash_id={$aBlockedIp.hash_id}&on_block=true&block_id={$aBlockedIp.blocked_id}');">{_p var="trust_ip"}</a></li>
                    <li><a href="#" onclick='$.ajaxCall("login-history.unblockIp", "hash_id={$aBlockedIp.hash_id}&block_id={$aBlockedIp.blocked_id}");'>{_p var="remove"}</a></li>
                </ul>
            </td>
        </tr>
        {/foreach}
        </tbody>
        </table>
    </div>

    {pager}
    {else}
    <div class="alert alert-empty">
        {_p var="no_blocked_ips_found"}
    </div>
    {/if}

{moderation}
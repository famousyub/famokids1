<div id="history-login-list">
    <div class="history-login-clear-btn">
        <a href="#" class="btn btn-sm btn-danger" onclick='$Core.jsConfirm({l}title: "{_p var="remove_all_sessions"}", message: "{_p var="are_you_sure_you_want_to_remove_all_sessions_history"}"{r}, function() {l}$.ajaxCall("login-history.removeAllHistories");{r});'>{_p var="clear_history"}</a>
    </div>

    {foreach from=$all_hashes key=key value=row_hash}
    <div class="history-login-device-item login-info ip_{$row_hash.ip_hash} device_{$row_hash.device_info.device_hash} {if $row_hash.is_ip_blocked} ip_blocked{elseif $row_hash.is_ip_trusted} ip_trusted{/if}{if $row_hash.is_device_blocked} device_blocked{/if}" id="login_history_{$row_hash.hash_id}">
        <div class="history-login-device-info">
            <div class="history-login-ip-block">
                <div class="history-login-device-name">{$row_hash.device_info.browser} {_p var='single_on'} {$row_hash.device_info.device} {$row_hash.device_info.platform}</div>
                <div class="history-login-device-status {if $row_hash.is_current} active_now{/if}">
                    {$row_hash.device_info.ip} {if $row_hash.is_current} <span class="active">- {_p var="active_now"}</span> {else}- {$row_hash.timestamp|convert_time:'core.global_update_time'}{/if}
                </div>
            </div>
            <div class="history-login-action-block">
                <ul class="single-action">
                    <li class="trust_ip">
                        <a href="javascript:void(0);" onclick="$.ajaxCall('login-history.trustIpFromHistory', 'hash_id={$row_hash.hash_id}');">
                            <span class="ico ico-check"></span>
                            <span class="trust_ip_text">{_p var="trust_ip"}</span>
                            <span class="ip_trusted_text">{_p var="ip_trusted"}</span>
                        </a>
                    </li>
                    {if !$row_hash.is_current && !$row_hash.is_current_device}
                    <li class="block_device">
                        <a  href="javascript:void(0);" onclick="$.ajaxCall('login-history.blockDevice', 'hash_id={$row_hash.hash_id}');">
                            <span class="ico ico-ban"></span>
                            <span class="block_device_text">{_p var="block_device"}</span>
                            <span class="device_blocked_text">{_p var="device_blocked"}</span>
                        </a>
                    </li>
                    {/if}
                    {if !$row_hash.is_current && !$row_hash.is_current_ip}
                    <li class="block_ip">
                        <a href="javascript:void(0);" onclick="$.ajaxCall('login-history.blockIpFromHistory', 'hash_id={$row_hash.hash_id}');">
                            <span class="ico ico-ban"></span>
                            <span class="block_ip_text">{_p var="block_ip"}</span>
                            <span class="ip_blocked_text">{_p var="ip_blocked"}</span>
                        </a>
                    </li>
                    {/if}
                    {if !$row_hash.is_current}
                        <li class="remove_ip"><a href="#" onclick='$Core.jsConfirm({l}title: "{_p var="remove_session"}", message: "{_p var="are_you_sure_you_want_to_remove_this_session_history"}"{r}, function() {l}$.ajaxCall("login-history.removeHistory", "hash_id={$row_hash.hash_id}");{r});'><span class="ico ico-trash-o"></span></a></li>
                    {/if}
                </ul>
            </div>
        </div>
    </div>
    {/foreach}
</div>
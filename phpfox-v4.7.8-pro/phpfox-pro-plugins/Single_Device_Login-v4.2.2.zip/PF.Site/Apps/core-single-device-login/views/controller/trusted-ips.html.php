{if count($aTrustedIps)}
<div class="table-responsive single-device-table">
    <table class="table">
        <thead>
        <tr>
            <th class="w20 table-th-checkbox">
                <input class="last_clicked_button" data-cmd="core.toggle_check_all" type="checkbox" />
            </th>
            <th {table_sort class="w60 centered" current=$current asc="ip_asc" desc="ip_desc" query="sort"}>
                {_p var='ip_address'}
            </th>
            <th {table_sort class="centered" current=$current asc="recent" desc="latest" query="sort"}>
                {_p var='time_trusted'}
            </th>
            <th>
                {_p var='action'}
            </th>
        </tr>
        </thead>
        <tbody>
        {foreach from=$aTrustedIps name=aTrustedIps key=iKey item=aTrustedIp}
        <tr id="row_ip_{$aTrustedIp.trusted_id}">
            <td class="table-td-checkbox">
                <div class="moderation_row">
                    <label class="item-checkbox">
                        <input type="checkbox" class="js_global_item_moderate" name="item_moderate[]" value="{$aTrustedIp.trusted_id}" id="check{$aTrustedIp.trusted_id}" />
                        <i class="ico ico-square-o"></i>
                    </label>
                </div>
            </td>
            <td>{$aTrustedIp.trusted_info}</td>
            <td>{$aTrustedIp.timestamp|convert_time:'core.global_update_time'}</td>
            <td>
                <ul class="single-action">
                    {if !$aTrustedIp.is_current}
                    <li><a href="javascript:void(0);" onclick="$.ajaxCall('login-history.blockIpFromTrusted', 'hash_id={$aTrustedIp.hash_id}&on_block=true&trusted_id={$aTrustedIp.trusted_id}');">{_p var="block_ip"}</a></li>
                    {/if}
                    <li><a href="#" onclick='$.ajaxCall("login-history.removeTrustIp", "hash_id={$aTrustedIp.hash_id}&trusted_id={$aTrustedIp.trusted_id}");'>{_p var="remove"}</a></li>
                </ul>
            </td>
        </tr>
        {/foreach}
        </tbody>
    </table>
</div>

{pager}
{else}
<div class="alert alert-empty">
    {_p var="no_trusted_ips_found"}
</div>
{/if}

{moderation}
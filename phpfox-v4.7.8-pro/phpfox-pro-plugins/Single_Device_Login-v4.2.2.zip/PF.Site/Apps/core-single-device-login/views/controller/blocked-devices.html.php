    {if $aBlockedDevices}
    <div class="table-responsive single-device-table">
        <table class="table">
            <thead>
            <tr>
                <th class="w20 table-th-checkbox">
                    <input class="last_clicked_button" data-cmd="core.toggle_check_all" type="checkbox" />
                </th>
                <th>
                    {_p var="device_type"}
                </th>
                <th {table_sort class="w60 centered" current=$current asc="device_asc" desc="device_desc" query="sort"}>
                    {_p var='ip_address'}
                </th>
                <th {table_sort class="centered" current=$current asc="recent" desc="latest" query="sort"}>
                    {_p var='time_blocked'}
                </th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            {foreach from=$aBlockedDevices name=aBlockedDevices key=iKey item=aBlockedDevice}
            <tr id="row_device_{$aBlockedDevice.blocked_id}">
                <td class="table-td-checkbox">
                    <div class="moderation_row">
                        <label class="item-checkbox">
                            <input type="checkbox" class="js_global_item_moderate" name="item_moderate[]" value="{$aBlockedDevice.blocked_id}" id="check{$aBlockedDevice.blocked_id}" />
                            <i class="ico ico-square-o"></i>
                        </label>
                    </div>
                </td>
                <td>
                    {$aBlockedDevice.device_info.browser} {_p var='single_on'} {$aBlockedDevice.device_info.device} {$aBlockedDevice.device_info.platform}
                </td>
                <td>{$aBlockedDevice.device_info.ip}</td>
                <td>{$aBlockedDevice.timestamp|convert_time:'core.global_update_time'}</td>
                <td>
                    <ul class="single-action">
                        <li><a href="#" onclick='$.ajaxCall("login-history.unblockDevice", "hash_id={$aBlockedDevice.hash_id}&block_id={$aBlockedDevice.blocked_id}");'>{_p var="unblock"}</a></li>
                    </ul>
                </td>
            </tr>
            {/foreach}
            </tbody>
        </table>
    </div>

    {pager}
    {else}
    <div class="alert alert-empty">
        {_p var="no_blocked_devices_found"}
    </div>
    {/if}

{moderation}
<?php
if (Phpfox::isUser() && Phpfox::isApps('phpFox_Single_Device_Login')) {
    Phpfox::getService('login-history')->checkLogout();
}
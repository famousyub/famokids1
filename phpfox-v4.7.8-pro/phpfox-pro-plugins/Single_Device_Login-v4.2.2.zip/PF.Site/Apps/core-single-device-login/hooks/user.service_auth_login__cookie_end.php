<?php
if ($aRow['user_id'] && Phpfox::isApps('phpFox_Single_Device_Login') && user('pf_single_login_enabled', 1, $aRow['user_group_id'])) {
    if (Phpfox::getUserBy('profile_page_id') == 0) {
        Phpfox::getService('login-history')->setCurrent($aRow['user_id']);
    }
}
<?php
$aPluginFiles[] = 'PF.Site/Apps/phpFox_Single_Device_Login';

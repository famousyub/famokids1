<?php
if (Phpfox::isUser() && Phpfox::isModule('login-history') && user('pf_single_login_enabled', 1)) {
    if (Phpfox::getUserBy('profile_page_id') == 0) {
        Phpfox::getService('login-history')->check();
    }
}
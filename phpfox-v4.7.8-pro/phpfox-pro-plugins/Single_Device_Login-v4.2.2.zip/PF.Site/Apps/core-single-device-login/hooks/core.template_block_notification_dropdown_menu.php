<?php

if(Phpfox::isApps('phpFox_Single_Device_Login') && user('pf_single_login_enabled')){
    $url = url('/login-history');
    $label = _p('Login History');
    echo '<li role="presentation">
        <a href="'. $url .'">
            <i class="fa fa-history"></i>
            ' . $label . '
        </a>
    </li>';
}
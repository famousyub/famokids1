<?php

$aBundleScripts[] = [
    'autoload.css' => 'app_core-single-device-login',
];
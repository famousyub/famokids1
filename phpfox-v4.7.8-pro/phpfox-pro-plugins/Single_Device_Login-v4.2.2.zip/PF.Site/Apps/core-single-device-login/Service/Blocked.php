<?php

namespace Apps\phpFox_Single_Device_Login\Service;

use Phpfox;
use Phpfox_Service;
use Phpfox_Request;

/**
 * @author Neil J. <neil@phpfox.com>
 * Class Blocked
 * @package Apps\phpFox_Single_Device_Login\Service
 */
class Blocked extends Phpfox_Service
{
    /**
     * @var string
     */
    private $_table_name = '';

    /**
     * Blocked constructor.
     */
    public function __construct()
    {
        $this->_table_name = Phpfox::getT('single_blocked');
    }

    /**
     * Check is IP current
     *
     * @param string $ip
     *
     * @return bool
     */
    public function isCurrentIp($ip)
    {
        return ($ip == Phpfox_Request::instance()->getIp()) ? true : false;
    }

    /**
     * Check is Device current
     *
     * @param string $device_hash
     *
     * @return bool
     */
    public function isCurrentDevice($device_hash)
    {
        $aCurrentHash = Single::get_object_hash()->getCurrentHash();
        return ($aCurrentHash['device_info']['device_hash'] == $device_hash) ? true : false;
    }

    /**
     * Block an ip
     *
     * @param int $hash_id
     * @param int|null $user_id
     *
     * @return bool
     */
    public function blockIp($hash_id, $user_id = null)
    {
        if ($user_id === null) {
            $user_id = Phpfox::getUserId();
        }

        $aHash = Single::get_object_hash()->getUserHash($hash_id);

        if (!isset($aHash['device_info'])) {
            //Hash not available or not belong to current user
            return false;
        }

        if ($this->isCurrentIp($aHash['device_info']['ip'])) {
            //Do not allow block current Ip
            return false;
        }

        //check is ip blocked?
        if ($this->isIpBlocked($aHash['device_info']['ip'])) {
            return false;
        }

        //type = 1: device; type =2 : ip
        $aInsert = [
            'type' => 2,
            'user_id' => $user_id,
            'hash_id' => (int)$hash_id,
            'blocked_info' => $aHash['device_info']['ip'],
            'timestamp' => PHPFOX_TIME
        ];
        $blockId = $this->database()->insert($this->_table_name, $aInsert);
        return $blockId ? true : false;
    }

    /**
     * Unblock an IP
     *
     * @param int $block_id
     * @param int|null $user_id
     *
     * return void
     */
    public function unblockIp($block_id, $user_id = null)
    {
        if ($user_id === null) {
            $user_id = Phpfox::getUserId();
        }

        $this->database()->delete($this->_table_name, 'blocked_id=' . (int)$block_id . ' AND user_id=' . (int)$user_id);
    }

    /**
     * Unblock an IP
     *
     * @param int $hash_id
     * @param int|null $user_id
     *
     * @return string|bool
     */
    public function unblockIpByHash($hash_id, $user_id = null)
    {
        if ($user_id === null) {
            $user_id = Phpfox::getUserId();
        }
        //Get hash information
        $aHashInfo = Single::get_object_hash()->getUserHash($hash_id, $user_id);

        $this->database()->delete($this->_table_name,
            'blocked_info="' . $aHashInfo['device_info']['ip'] . '" AND user_id=' . (int)$user_id);

        return (isset($aHashInfo['device_info']['ip']) ? $aHashInfo['device_info']['ip'] : false);
    }

    /**
     * Check an IP is blocked?
     *
     * @param string $ip
     *
     * @return bool
     */
    public function isIpBlocked($ip)
    {
        $count = $this->database()->select('count(*)')
            ->from($this->_table_name)
            ->where('blocked_info="' . Phpfox::getLib('parse.input')->clean($ip) . '"')
            ->executeField();
        return $count ? true : false;
    }

    /**
     * block a device
     *
     * @param int $hash_id
     *
     * @return bool|string of device hash info
     */
    public function blockDevice($hash_id)
    {
        $aHash = Single::get_object_hash()->getUserHash($hash_id);

        if (!isset($aHash['device_info'])) {
            //Hash not available or not belong to current user
            return false;
        }
        //check is device blocked
        $count = $this->database()->select('COUNT(*)')
            ->from($this->_table_name)
            ->where('blocked_info="' . $aHash['device_info']['device_hash'] . '"')
            ->executeField();
        if ($count) {
            //Device already blocked
            return false;
        }
        //type = 1: device; type =2 : ip
        $aInsert = [
            'type' => 1,
            'user_id' => Phpfox::getUserId(),
            'hash_id' => (int)$hash_id,
            'blocked_info' => $aHash['device_info']['device_hash'],
            'timestamp' => PHPFOX_TIME
        ];
        $blockId = $this->database()->insert($this->_table_name, $aInsert);
        return $blockId ? $aHash['device_info']['device_hash'] : false;
    }

    /**
     * Unblock a device
     *
     * @param int $block_id
     * @param int|null $user_id
     *
     * @return void
     */
    public function unblockDevice($block_id, $user_id = null)
    {
        if ($user_id === null) {
            $user_id = Phpfox::getUserId();
        }

        $this->database()->delete($this->_table_name, 'blocked_id=' . (int)$block_id . ' AND user_id=' . (int)$user_id);
    }

    /**
     * Check a device is blocked?
     *
     * @param string $device_hash
     *
     * @return bool
     */
    public function isDeviceBlocked($device_hash)
    {
        $count = $this->database()->select('count(*)')
            ->from($this->_table_name)
            ->where('blocked_info="' . Phpfox::getLib('parse.input')->clean($device_hash) . '"')
            ->executeField();
        return $count ? true : false;
    }

    /**
     * Get Blocked IPs by conditions
     *
     * @param array $aConditions
     * @param string $sSort
     * @param int $iPage
     *
     * @return array
     */
    public function getBlockedIps($aConditions, $sSort, $iPage = 1)
    {
        //Set blocked type is IP
        $aConditions[] = ' AND blocked_ip.type = 2 AND blocked_ip.user_id=' . (int)Phpfox::getUserId();

        //Count total IPs are blocked by this user
        $iTotal = $this->database()->select('COUNT(*)')
            ->from($this->_table_name, 'blocked_ip')
            ->where($aConditions)
            ->executeField();

        //Get blocked ips result
        $result = $this->database()->select('*')
            ->from($this->_table_name, 'blocked_ip')
            ->where($aConditions)
            ->order($sSort)
            ->limit($iPage, 7)
            ->executeRows();

        return [$iTotal, $result];
    }

    /**
     * Get blocked devices by conditions
     *
     * @param array $aConditions
     * @param string $sSort
     * @param int $iPage
     *
     * @return array
     */
    public function getBlockedDevices($aConditions, $sSort, $iPage = 1)
    {
        //Set blocked type is Device
        $aConditions[] = ' AND blocked_device.type = 1 AND blocked_device.user_id=' . (int)Phpfox::getUserId();

        //Count total IPs are blocked by this user
        $iTotal = $this->database()->select('COUNT(*)')
            ->from($this->_table_name, 'blocked_device')
            ->join(':single_hash', 'sh', 'sh.hash_id=blocked_device.hash_id')
            ->where($aConditions)
            ->executeField();

        //Get blocked ips result
        $results = $this->database()->select('sh.*, blocked_device.*')
            ->from($this->_table_name, 'blocked_device')
            ->join(':single_hash', 'sh', 'sh.hash_id=blocked_device.hash_id')
            ->where($aConditions)
            ->order($sSort)
            ->limit($iPage, 7)
            ->executeRows();

        foreach ($results as $key => $result) {
            $results[$key]['device_info'] = json_decode($result['device_info'], true);
        }
        return [$iTotal, $results];
    }

    /**
     * Get hash_id from blocked_id
     * @param $blocked_id
     *
     * @return int
     */
    public function getHashId($blocked_id)
    {
        $hash_id = $this->database()->select('hash_id')
            ->from($this->_table_name)
            ->where('blocked_id=' . (int)$blocked_id)
            ->executeField();
        return (int)$hash_id;
    }

    /**
     * Check ip or device are blocked
     *
     * @return bool
     */
    public function isAllowLogin()
    {
        $aDevice = Single::get_object_device()->getDeviceInfo();


        //check IP is trusted
        if (Single::get_object_trust()->isIpTrusted($aDevice['ip'])) {
            return true;
        }

        //Check IP is blocked?
        if (Single::get_object_block()->isIpBlocked($aDevice['ip'])) {
            return false;
        }

        //Check Device is blocked?
        if (Single::get_object_block()->isDeviceBlocked($aDevice['device_hash'])) {
            return false;
        }

        if ($hash_id = Single::get_object_hash()->isHashRemoved()) {
            Single::get_object_hash()->permanentlyRemoveHash($hash_id);
            return false;
        }

        return true;
    }
}

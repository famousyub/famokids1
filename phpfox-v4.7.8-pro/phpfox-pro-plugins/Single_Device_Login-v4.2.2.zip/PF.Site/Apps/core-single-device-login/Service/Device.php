<?php

namespace Apps\phpFox_Single_Device_Login\Service;

use Jenssegers\Agent\Agent;
use Phpfox;
use Phpfox_Request;
use Phpfox_Service;

/**
 * Class Device
 * @package Apps\phpFox_Single_Device_Login\Service
 */
class Device extends Phpfox_Service
{
    /**
     * @var Agent|null
     */
    private $_agent = null;

    /**
     * Device constructor.
     */
    public function __construct()
    {
        $this->_agent = new Agent();
    }

    /**
     * return hash of device
     * @param $aInfo
     * @return string
     */
    public function generateToken($aInfo)
    {
        return md5($aInfo['device'] . $aInfo['platform'] . $aInfo['browser'] . $aInfo['ip']);
    }

    /**
     * @deprecated
     * @return array
     */
    public function getToken()
    {
        $aInfo = [
            'device' => $this->_agent->device(),
            'platform' => $this->_agent->platform() . ' ' . $this->_agent->version($this->_agent->platform()),
            'browser' => $this->_agent->browser(),
            'time_stamp' => PHPFOX_TIME,
            'ip' => Phpfox_Request::instance()->getIp()
        ];
        $sToken = $this->generateToken($aInfo);
        return [$sToken, $aInfo];
    }

    /**
     * @deprecated
     * @param bool $bOverwrite
     * @param null $userId
     * @return array|mixed
     */
    public function addToken($bOverwrite = true, $userId = null)
    {
        if ($userId === null) {
            $userId = user()->id;
        }

        list($sToken, $aInfo) = $this->getToken();
        $sTokensKey = 'user/' . $userId . '/device_tokens';
        $sTokenKey = 'user/' . $userId . '/device_token';
        $aTokens = storage()->all($sTokensKey);
        $iTokenId = 0;
        foreach ($aTokens as $aToken) {
            if ($aToken->value == $sToken) {
                if ($bOverwrite) {
                    $iTokenId = $aToken->id;
                    $aInfo['verified'] = true;
                    break;
                } else {
                    return error(_p('The token is already added.'));
                }
            }
        }
        if (!$iTokenId) {
            $aInfo['verified'] = false;
            $iTokenId = storage()->set($sTokensKey, $sToken);
        }

        storage()->del($sTokenKey, $iTokenId);
        storage()->set($sTokenKey, $aInfo, $iTokenId);
        return ['token' => $sToken, 'token_id' => $iTokenId];
    }

    /**
     * @deprecated
     * @param string $sToken
     * @param int $userId
     * @return int
     */
    public function getTokenId($sToken, $userId = null)
    {
        if ($userId === null) {
            $userId = user()->id;
        }
        $sTokensKey = 'user/' . $userId . '/device_tokens';
        $aTokens = storage()->all($sTokensKey);
        $iTokenId = 0;
        foreach ($aTokens as $aToken) {
            if ($aToken->value == $sToken) {
                $iTokenId = $aToken->id;
                break;
            }
        }
        return $iTokenId;
    }

    /**
     * @deprecated
     * @param $iTokenId
     * @param int $userId
     * @return bool
     */
    public function getTokenInfo($iTokenId, $userId = null)
    {
        if ($userId === null) {
            $userId = user()->id;
        }
        $sTokenKey = 'user/' . $userId . '/device_token';
        $aInfo = storage()->get($sTokenKey, $iTokenId);
        return ($aInfo ? $aInfo->value : false);
    }

    /**
     * @deprecated
     * @param $id
     * @param int $userId
     */
    public function deleteTokenById($id, $userId = null)
    {
        if ($userId === null) {
            $userId = user()->id;
        }
        storage()->delById($id);
        storage()->del('user/' . $userId . '/device_token', $id);
    }


    /**
     * @deprecated
     * @param int $userId
     * @return array
     */
    public function getCurrent($userId = null)
    {
        if ($userId === null) {
            $userId = user()->id;
        }
        $key = 'user/' . $userId . '/current_token';
        $current = storage()->get($key);
        return ($current ? $current->value : []);
    }

    /**
     * @deprecated
     *
     * @param $iTokenId
     * @param int $userId
     * @return bool
     */
    public function updateTimestamp($iTokenId, $userId = null)
    {
        if ($userId === null) {
            $userId = user()->id;
        }
        $sTokenKey = 'user/' . $userId . '/device_token';
        $aInfo = storage()->get($sTokenKey, $iTokenId);
        if (!$aInfo) {
            return false;
        }
        $aInfo = (array)$aInfo->value;
        $aInfo['time_stamp'] = PHPFOX_TIME;
        storage()->del($sTokenKey, $iTokenId);
        storage()->set($sTokenKey, $aInfo, $iTokenId);
        return true;
    }


    /**
     * @deprecated
     * @param int $userId
     * @return array
     */
    public function getHistory($userId = null)
    {
        if ($userId === null) {
            $userId = user()->id;
        }

        $key = 'user/' . $userId . '/device_token';
        $aRows = storage()->all($key, 'cache_id DESC');
        $aResult = [];
        foreach ($aRows as $row) {
            $row->value->time_display = Phpfox::getLib('date')->convertTime((int)$row->value->time_stamp);
            $row->value->current = false;
            $aResult[] = (array)$row->value;
        }

        if (!empty($aResult)) {
            $aResult[0]['current'] = true;
        }

        return $aResult;
    }

    //below is new code
    /**
     * @return array
     */
    public function getDeviceInfo()
    {
        $aDeviceInfo = [
            'device' => $this->_agent->device(),
            'platform' => $this->_agent->platform() . ' ' . $this->_agent->version($this->_agent->platform()),
            'browser' => $this->_agent->browser(),
            'time_stamp' => PHPFOX_TIME,
            'ip' => Phpfox_Request::instance()->getIp()
        ];
        $aDeviceInfo['device_hash'] = $this->generateToken($aDeviceInfo);

        return $aDeviceInfo;
    }

}
<?php

namespace Apps\phpFox_Single_Device_Login\Service;

use Phpfox_Service;
use Phpfox;

/**
 * Class Callback
 *
 * @author Neil J <neil@phpfox.com>
 * @package Apps\phpFox_Single_Device_Login\Service
 */
class Callback extends Phpfox_Service
{
    public function getNotificationSettings()
    {
        return array(
            'login-history.unknown_login' => array(
                'phrase' => _p('unknown_login'),
                'default' => 1
            )
        );
    }

    public function getCopyUserInfoStatus()
    {
        return [
            "login_history" => [
                "tittle" => _p("Login history"),
                "description" => _p("Your login history")
            ]
        ];
    }

    public function processCopyUserInfo_login_history()
    {
        $aHistoryLogin = Phpfox::getLib('database')->select('device_info')
            ->from(':single_hash')
            ->where('user_id=' . Phpfox::getUserId())
            ->executeRows();
        $aReturn = [];
        foreach ($aHistoryLogin as $aLogin) {
            $aDeviceInfo = json_decode($aLogin['device_info'], true);
            unset($aDeviceInfo['device_hash']);
            $aReturn[] = $aDeviceInfo;
        }
        return [
            'files' => [],
            'data' => json_encode($aReturn, JSON_PRETTY_PRINT)
        ];
    }
}
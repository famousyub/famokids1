<?php

namespace Apps\phpFox_Single_Device_Login\Service;

use Phpfox;
use Phpfox_Service;

/**
 * @author Neil J. <neil@phpfox.com>
 * Class Hash
 * @package Apps\phpFox_Single_Device_Login\Service
 */
class Hash extends Phpfox_Service
{
    const _COOKIE_HASH = 'single-hash';

    /**
     * @var string Main database table for this class
     */
    private $_table_name = '';

    /**
     * @var null
     */
    private $_isCurrent = null;

    /**
     * Hash constructor.
     */
    public function __construct()
    {
        $this->_table_name = Phpfox::getT('single_hash');
    }

    /**
     * Get a device and ip info from hash_id of an user
     *
     * @param int $hash_id
     * @param null|int $user_id
     *
     * @return array|false
     */
    public function getUserHash($hash_id, $user_id = null)
    {
        $user_id = $this->_update_user_id($user_id);

        //Read data from database
        $all_hash = Phpfox::getLib('database')->select('*')
            ->from($this->_table_name)
            ->where('user_id=' . (int)$user_id . ' AND hash_id=' . (int)$hash_id . ' AND is_removed = 0')
            ->executeRow();

        //parse device information
        if (isset($all_hash['device_info'])) {
            $all_hash['device_info'] = json_decode($all_hash['device_info'], true);
            return $all_hash;
        } else {
            return false;
        }
    }

    public function getCurrentHash($user_id = null)
    {
        $user_id = $this->_update_user_id($user_id);

        //Read data from database
        $all_hash = Phpfox::getLib('database')->select('*')
            ->from($this->_table_name)
            ->where('user_id=' . (int)$user_id . ' AND is_current=1 AND is_removed = 0')
            ->executeRow();

        //parse device information
        if (isset($all_hash['device_info'])) {
            $all_hash['device_info'] = json_decode($all_hash['device_info'], true);
            return $all_hash;
        } else {
            return false;
        }
    }

    /**
     * Get all hash of a user
     * Why not cache?: we do not cache this value because as phpfox agreements: do not cache data from specific user
     *
     * @param null|int $user_id
     * @return array
     */
    public function getAll($user_id = null)
    {
        $user_id = $this->_update_user_id($user_id);

        //Read data from database
        $all_hashes = Phpfox::getLib('database')->select('*')
            ->from($this->_table_name)
            ->where('user_id=' . (int)$user_id . ' AND is_removed = 0')
            ->order('timestamp DESC')
            ->executeRows();

        //parse device information
        foreach ($all_hashes as $key => $hash) {
            $all_hashes[$key]['device_info'] = json_decode($hash['device_info'], true);
            $all_hashes[$key]['is_ip_blocked'] = Single::get_object_block()->isIpBlocked($all_hashes[$key]['device_info']['ip']);
            $all_hashes[$key]['is_ip_trusted'] = Single::get_object_trust()->isIpTrusted($all_hashes[$key]['device_info']['ip']);
            $all_hashes[$key]['ip_hash'] = md5($all_hashes[$key]['device_info']['ip']);
            $all_hashes[$key]['is_device_blocked'] = Single::get_object_block()->isDeviceBlocked($all_hashes[$key]['device_info']['device_hash']);
        }

        return $all_hashes;
    }

    /**
     * Check is a hash marked as delete or not
     *
     * @param null|int $user_id
     *
     * @return bool
     */
    public function isHashRemoved($user_id = null)
    {
        $user_id = $this->_update_user_id($user_id);

        $hash_code = Phpfox::getCookie(self::_COOKIE_HASH);
        $hash_id = Phpfox::getLib('database')->select('hash_id')
            ->from(':single_hash')
            ->where('hash_code="' . $hash_code . '" AND is_removed=1 AND user_id=' . (int)$user_id)
            ->executeField();

        return ($hash_id) ? $hash_id : false;
    }

    /**
     * Permanently remove a hash of user
     *
     * @param int $hash_id
     * @param null|int $user_id
     *
     * @return void
     */
    public function permanentlyRemoveHash($hash_id, $user_id = null)
    {
        $user_id = $this->_update_user_id($user_id);
        $this->database()->delete($this->_table_name, 'hash_id=' . (int)$hash_id . ' AND user_id=' . (int)$user_id);
    }

    /**
     * Remove hash when logout
     *
     * @return void
     */
    public function removeLogoutHash()
    {
        $hash_code = Phpfox::getCookie(self::_COOKIE_HASH);
        $this->database()->delete($this->_table_name, 'hash_code="' . $hash_code . '"');
    }

    /**
     * Generate new hash or update exist hash to active
     *
     * @param null|int $user_id
     * @return array
     */
    public function addHash($user_id = null)
    {
        $user_id = $this->_update_user_id($user_id);

        $hash_code = Phpfox::getCookie(self::_COOKIE_HASH);
        $hash_id = Phpfox::getLib('database')->select('hash_id')
            ->from(':single_hash')
            ->where('hash_code="' . $hash_code . '" AND user_id=' . (int)$user_id)
            ->executeField();
        //This device is accessed before
        if ($hash_id) {
            Phpfox::getLib('database')->update(':single_hash', [
                'device_info' => json_encode(Single::get_object_device()->getDeviceInfo()),
                'timestamp' => PHPFOX_TIME,
                'is_current' => 1
            ], 'hash_id=' . $hash_id);
            $is_new_hash = false;
        } else {
            //This is new device
            $hash_code = md5('support-hash' . md5(time()) . md5(mt_rand(0, PHP_INT_MAX)));
            Phpfox::setCookie(self::_COOKIE_HASH, $hash_code);
            $hash_id = (int)Phpfox::getLib('database')->insert(':single_hash', [
                'hash_code' => $hash_code,
                'user_id' => $user_id,
                'is_current' => 1,
                'is_removed' => 0,
                'device_info' => json_encode(Single::get_object_device()->getDeviceInfo()),
                'timestamp' => PHPFOX_TIME
            ]);
            $is_new_hash = true;
        }
        //Set other hash is inactive
        $this->setInactive($hash_id, $user_id);

        $this->_isCurrent = true;
        //return result
        return [$is_new_hash, $hash_id];
    }

    public function isCurrentActive($user_id = null)
    {
        if (!Phpfox::isUser()) {
            return false;
        }
        $user_id = $this->_update_user_id($user_id);
        if ($this->_isCurrent === true) {
            return true;
        }
        $hash_code = Phpfox::getCookie(self::_COOKIE_HASH);
        $is_current = Phpfox::getLib('database')->select('is_current')
            ->from(':single_hash')
            ->where('hash_code="' . $hash_code . '" AND user_id=' . (int)$user_id)
            ->executeField();

        return ($is_current ? true : false);
    }

    /**
     * Marked a hash as removed
     *
     * @param int $hash_id
     * @param null|int $user_id
     */
    public function removeHash($hash_id, $user_id = null)
    {
        $user_id = $this->_update_user_id($user_id);
        $this->database()->update($this->_table_name, [
            'is_removed' => 1
        ], 'user_id=' . (int)$user_id . ' AND hash_id=' . (int)$hash_id);
    }

    /**
     * @param null $user_id
     *
     * @return void
     */
    public function removeAllHistories($user_id = null)
    {
        $user_id = $this->_update_user_id($user_id);

        $this->database()->update($this->_table_name, [
            'is_removed' => 1
        ], 'user_id=' . (int)$user_id . ' AND is_current=0');
    }

    public function setInactive($hash_id, $user_id = null)
    {
        $user_id = $this->_update_user_id($user_id);

        Phpfox::getLib('database')->update($this->_table_name, [
            'is_current' => 0
        ], 'user_id=' . (int)$user_id . ' AND hash_id <> ' . (int)$hash_id);
    }

    /**
     * return current user ID if null
     *
     * @param null|int $user_id
     * @return int
     */
    private function _update_user_id($user_id = null)
    {
        return ($user_id === null) ? Phpfox::getUserId() : $user_id;
    }
}

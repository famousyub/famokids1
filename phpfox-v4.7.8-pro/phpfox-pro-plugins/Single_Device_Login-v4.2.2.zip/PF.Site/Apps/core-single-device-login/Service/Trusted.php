<?php

namespace Apps\phpFox_Single_Device_Login\Service;

use Phpfox;
use Phpfox_Service;

/**
 * @author Neil J. <neil@phpfox.com>
 * Class Trusted
 * @package Apps\phpFox_Single_Device_Login\Service
 */
class Trusted extends Phpfox_Service
{
    /**
     * @var string Trusted table name
     */
    private $_table_name = '';

    /**
     * Trusted constructor.
     */
    public function __construct()
    {
        $this->_table_name = Phpfox::getT('single_trusted');
    }

    /*###############################################################################################
     * Get methods
     ################################################################################################*/

    public function getTrustedIps($aConditions, $sSort, $iPage = 1)
    {
        //Set blocked type is IP
        $aConditions[] = ' AND trusted_ip.type = 2 AND trusted_ip.user_id=' . (int)Phpfox::getUserId();

        //Count total IPs are trusted by this user
        $iTotal = $this->database()->select('COUNT(*)')
            ->from($this->_table_name, 'trusted_ip')
            ->where($aConditions)
            ->executeField();

        if ($iTotal) {
            //Get trusted ips result
            $results = $this->database()->select('*')
                ->from($this->_table_name, 'trusted_ip')
                ->where($aConditions)
                ->order($sSort)
                ->limit($iPage, 7)
                ->executeRows();
        } else {
            $results = [];
        }

        return [$iTotal, $results];
    }

    /**
     * Check an IP is blocked?
     *
     * @param string $ip
     * @param null|int $user_id
     *
     * @return bool
     */
    public function isIpTrusted($ip, $user_id = null)
    {
        if ($user_id === null) {
            $user_id = Phpfox::getUserId();
        }

        $count = $this->database()->select('count(*)')
            ->from($this->_table_name)
            ->where('trusted_info="' . Phpfox::getLib('parse.input')->clean($ip) . '" AND user_id =' . (int) $user_id)
            ->executeField();
        return $count ? true : false;
    }

    /*###############################################################################################
    * Action methods (add, remove,...)
    ################################################################################################*/

    /**
     * Add an Ip to trust list
     *
     * @param int $hash_id
     * @return bool
     */
    public function trustIp($hash_id)
    {
        $aHash = Single::get_object_hash()->getUserHash($hash_id);

        if (!isset($aHash['device_info'])) {
            //Hash not available or not belong to current user
            return false;
        }
        //type = 1: device; type =2 : ip
        $aInsert = [
            'type' => 2,
            'user_id' => Phpfox::getUserId(),
            'hash_id' => (int)$hash_id,
            'trusted_info' => $aHash['device_info']['ip'],
            'timestamp' => PHPFOX_TIME
        ];
        $trustId = $this->database()->insert($this->_table_name, $aInsert);
        return $trustId ? true : false;
    }

    /**
     * Remove an IP from trusted list
     *
     * @param int $trusted_id
     * @param int|null $user_id
     *
     * @return void
     */
    public function removeTrustIp($trusted_id, $user_id = null)
    {
        if ($user_id === null) {
            $user_id = Phpfox::getUserId();
        }

        $this->database()->delete($this->_table_name,
            'user_id=' . (int)$user_id . ' AND trusted_id=' . (int)$trusted_id);
    }

    /**
     * Remove Trusted IP by hash_id
     *
     * @param int $hash_id
     * @param null|int $user_id
     *
     * @return string|bool of IP address
     */
    public function removeTrustIpByHash($hash_id, $user_id = null)
    {
        if ($user_id === null) {
            $user_id = Phpfox::getUserId();
        }
        //Get hash information
        $aHashInfo = Single::get_object_hash()->getUserHash($hash_id, $user_id);

        //Remove from trusted with this ip and user_id
        $this->database()->delete($this->_table_name, 'user_id=' . (int) $user_id . ' AND trusted_info="' . $aHashInfo['device_info']['ip'] . '"');

        return (isset($aHashInfo['device_info']['ip']) ? $aHashInfo['device_info']['ip'] : false);
    }

    /**
     * Block an IP from trusted list
     *
     * @param int $trusted_id
     * @param null $user_id
     *
     * @return bool
     */
    public function blockIpFromTrusted($trusted_id, $user_id = null)
    {
        if ($user_id === null) {
            $user_id = Phpfox::getUserId();
        }
        $hash_id = $this->database()->select('hash_id')
            ->from($this->_table_name)
            ->where('trusted_id=' . (int)$trusted_id)
            ->executeField();

        $result = Single::get_object_block()->blockIp($hash_id, $user_id);

        if ($result) {
            //IP can block. Remove it from trust list
            $this->removeTrustIp($trusted_id);
            return true;
        } else {
            //Can't block this IP
            return false;
        }
    }
}

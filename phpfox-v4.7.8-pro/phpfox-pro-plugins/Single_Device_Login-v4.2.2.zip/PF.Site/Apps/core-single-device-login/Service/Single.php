<?php

namespace Apps\phpFox_Single_Device_Login\Service;

use Phpfox;
use Phpfox_Error;
use Phpfox_Service;
use Phpfox_Url;

/**
 * @author Neil J. <neil@phpfox.com>
 * Class Single
 * @package Apps\phpFox_Single_Device_Login\Service
 */
class Single extends Phpfox_Service
{
    private $_bShouldCheck = true;

    public function getSectionMenu()
    {
        if (Phpfox::isUser()) {
            $aFilterMenu = [
                _p('history') => '',
                _p('trusted_ips') => 'login-history.trusted-ips',
                _p('blocked_devices') => 'login-history.blocked-devices',
                _p('blocked_ips') => 'login-history.blocked-ips',
            ];
        } else {
            $aFilterMenu = [];
        }

        return $aFilterMenu;
    }

    /**
     * @param null $userId
     * @return bool
     * @throws \Exception
     */
    public function setCurrent($userId = null)
    {
        if ($userId === null) {
            $userId = Phpfox::getUserId();
        }

        //Check IP or device is blocked
        if (!Single::get_object_block()->isAllowLogin()) {
            Phpfox::addMessage(_p('you_blocked_this_device_or_ip'));
            Phpfox::getService('user.auth')->reset();
            Phpfox::getService('user.auth')->logout();
        } else {
            list($is_new_hash,) = self::get_object_hash()->addHash($userId);

            if ($is_new_hash) {
                $this->noticeByEmail($userId);
            }
        }
        $this->_bShouldCheck = false;
        return true;
    }

    /**
     * @param null $userId
     * @return bool
     * @throws \Exception
     */
    public function noticeByEmail($userId = null)
    {
        if (!setting('pf_single_login_email_notice', 1) && !Phpfox::isAdminPanel()) {
            return false;
        }

        if ($userId === null) {
            $userId = user()->id;
        }

        $aCurrentTokenInfo = self::get_object_hash()->getCurrentHash($userId);
        $aInfo = [
            'link' => url('user.setting'),
            'manage_link' => Phpfox::getLib('url')->makeUrl('login-history'),
            'device' => $aCurrentTokenInfo['device_info']['device'],
            'platform' => $aCurrentTokenInfo['device_info']['platform'],
            'browser' => $aCurrentTokenInfo['device_info']['browser'],
            'ip' => $aCurrentTokenInfo['device_info']['ip'],
        ];

        Phpfox::getLib('mail')->to($userId)
            ->subject(_p('Unknown Login Alert!'))
            ->message(_p("Someone has just logged in to your account on {{ device }} {{ platform }} - {{ browser }} with IP address: {{ ip }}. If this wasn't you, click <a href=\"{{ link }}\">here</a> to change your password. Otherwise, you can view your login history at <a href=\"{{ manage_link }}\">here</a>.",
                $aInfo))
            ->notification('login-history.unknown_login')
            ->translated()
            ->send();

        return true;
    }

    /**
     * Check current session is valid
     *
     * @return bool
     * @throws \Exception
     */
    public function check()
    {
        if (!Phpfox::isUser()) {
            return false;
        }

        if (!auth() || !user('pf_single_login_enabled', 1)) {
            return false;
        }
        $aCurrentTokenInfo = self::get_object_hash()->getCurrentHash();

        if (self::get_object_trust()->isIpTrusted($aCurrentTokenInfo['device_info']['ip'])) {
            self::get_object_hash()->addHash();
            return false;
        }

        if ($this->_bShouldCheck) {
            $isCurrentActive = self::get_object_hash()->isCurrentActive();

            //Log out
            $bLogout = false;

            //Check IP or device is blocked
            if (!Single::get_object_block()->isAllowLogin()) {
                $bLogout = true;
                Phpfox::addMessage(_p('you_blocked_this_device_or_ip'));
                Phpfox::getService('user.auth')->reset();
                Phpfox::getService('user.auth')->logout();
            }

            if (!$isCurrentActive && !Phpfox::getParam('login-history.pf_single_login_multiple', 1)) {
                $bLogout = true;
                Phpfox::getService('user.auth')->reset();
                Phpfox::getService('user.auth')->logout();
            }

            if (!$isCurrentActive) {
                $aInfo = [
                    'link' => url('user.setting'),
                    'manage_link' => Phpfox::getLib('url')->makeUrl('login-history'),
                    'device' => $aCurrentTokenInfo['device_info']['device'],
                    'platform' => $aCurrentTokenInfo['device_info']['platform'],
                    'browser' => $aCurrentTokenInfo['device_info']['browser'],
                    'ip' => $aCurrentTokenInfo['device_info']['ip'],
                ];
                $this->noticeByPopup($bLogout, $aInfo);
            }

            self::get_object_hash()->addHash();
            $this->_bShouldCheck = true;
        }
        return true;
    }

    public function checkLogout()
    {
        self::get_object_hash()->removeLogoutHash();
    }

    /**
     * Notice user by popup
     *
     * @param $bLogout
     * @param $aInfo
     * @return bool
     * @throws \Exception
     */
    public function noticeByPopup($bLogout, $aInfo)
    {
        if (!setting('pf_single_login_popup_notice', 1) || Phpfox::isAdminPanel()) {
            return false;
        }
        if ($bLogout) {
            if (isset($aInfo['device']) && !empty($aInfo['device'])) {
                $message = _p('You are forced to sign out here because someone has just logged in to your account on {{ device }} {{ platform }} - {{ browser }} with IP address: {{ ip }}',
                    $aInfo);
            } else {
                //If can't get other device information
                $message = _p('you_are_forced_to_sign_out_here_because_someone_has_just_logged_into_your_account_on_other_device');
            }
        } else {
            if (isset($aInfo['device']) && !empty($aInfo['device'])) {
                $message = _p('Your account has just been logged in on {{ device }} {{ platform }} - {{ browser }} with IP address: {{ ip }}',
                    $aInfo);
            } else {
                $message = _p('your_account_has_just_been_also_logged_in_on_other_device');
            }
        }
        if (Phpfox_Url::instance()->getUri() == '/_ajax/') {
            $message .= '<br />';
            $message .= str_replace("'", "\\'", _p('if_this_wasn_t_you_consider_to_change_your_password_you_can_also_view_this_session_to_get_more_information'));
            $message .= '<br />';
            $message .= '<div class="center-block single_block"  style="width: 200px;"><a class="btn btn-default btn-block m-1" href="' . Phpfox::getLib('url')->makeUrl('user.setting') . '"> ' . _p('account_settings') . '</a>';
            $message .= '<a class="btn btn-default btn-block m-1" href="' . Phpfox::getLib('url')->makeUrl('login-history') . '"> ' . _p('view_session') . '</a>';
            $message .= '</div>';
            Phpfox::getLib('ajax')->call("tb_show('" . _p('Warning') . "', '','','" . $message . "');");
        } else {
            Phpfox_Error::set($message);
        }
        return true;
    }

    /*#*******************************************************************************
            Factory functions
    *********************************************************************************/
    /**
     * @return Device
     */
    public static function get_object_device()
    {
        return (new Device());
    }

    /**
     * Singleton Hash
     *
     * @var null|Hash
     */

    private static $_oHash = null;

    /**
     * @return Hash
     */
    public static function get_object_hash()
    {
        if (self::$_oHash === null) {
            self::$_oHash = new Hash();
        }
        return self::$_oHash;
    }

    /**
     * @return Trusted
     */
    public static function get_object_trust()
    {
        return (new Trusted());
    }

    /**
     * @return Blocked
     */
    public static function get_object_block()
    {
        return (new Blocked());
    }
}
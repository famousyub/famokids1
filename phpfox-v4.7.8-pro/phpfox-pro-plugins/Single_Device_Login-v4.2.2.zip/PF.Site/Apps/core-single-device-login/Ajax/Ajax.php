<?php

namespace Apps\phpFox_Single_Device_Login\Ajax;

use Phpfox_Ajax;
use Apps\phpFox_Single_Device_Login\Service\Single;
use Phpfox;

/**
 * Class Ajax
 * @author Neil J. <neil@phpfox.com>
 * @package Apps\phpFox_Single_Device_Login\Ajax
 */
class Ajax extends Phpfox_Ajax
{
    /*########################################################
    End History page
    ########################################################*/
    /**
     * Page: History page.
     * Mark a session as remove
     *
     * return void
     */
    public function removeHistory()
    {
        $hash_id = $this->get('hash_id');
        Single::get_object_hash()->removeHash($hash_id);
        $this->call("$('#login_history_$hash_id').fadeOut();");
    }

    /**
     * Page: History page.
     * Block an ip
     *
     * return void
     */
    public function blockIpFromHistory()
    {
        $hash_id = $this->get('hash_id');

        //Remove from trust list
        $ip_address = Single::get_object_trust()->removeTrustIpByHash($hash_id);

        if (Single::get_object_block()->blockIp($hash_id)) {
            $this->call("$('.ip_" . md5($ip_address) . "').addClass('ip_blocked').removeClass('ip_trusted');");
            $this->showMessage(_p('ip_successfully_blocked'));
        } else {
            $this->showMessage(_p('cant_block_this_ip'));
        }
    }

    public function trustIpFromHistory()
    {
        $hash_id = $this->get('hash_id');

        //Remove from blocked list
        $ip_address = Single::get_object_block()->unblockIpByHash($hash_id);

        if (Single::get_object_trust()->trustIp($hash_id)) {
            $this->call("$('.ip_" . md5($ip_address) . "').addClass('ip_trusted').removeClass('ip_blocked');");
            $this->showMessage(_p('ip_successfully_trusted'));
        } else {
            $this->showMessage(_p('cant_trust_this_ip'));
        }
    }

    private function showMessage($message)
    {
        $this->call("$('#public_message').html('" . $message . "').css('margin-bottom','0').show();");
        $this->call('setTimeout(function() {$Core.publicMessageSlideDown();}, 3000);');
    }

    /**
     * block a device
     */
    public function blockDevice()
    {
        $hash_id = $this->get('hash_id');
        $device_info = Single::get_object_block()->blockDevice($hash_id);

        $this->call("$('.device_" . $device_info . "').addClass('device_blocked');");
        $this->showMessage(_p('device_successfully_blocked'));
    }

    public function removeAllHistories()
    {
        Single::get_object_hash()->removeAllHistories();
        $this->reload();
    }

    /*########################################################
     End History page
     ########################################################*/

    /**
     * add an ip to trust list
     */
    public function trustIp()
    {
        $is_on_block = $this->get('on_block');
        $hash_id = $this->get('hash_id');
        if ($is_on_block) {
            $block_id = $this->get('block_id');
            Single::get_object_block()->unblockIp($block_id);
            $this->call("$('#row_ip_$block_id').remove();");
            $this->showMessage(_p('ip_successfully_trusted'));
        }

        Single::get_object_trust()->trustIp($hash_id);
    }

    public function unblockDevice()
    {
        $block_id = $this->get('block_id');
        Single::get_object_block()->unblockDevice($block_id);
        $this->call("$('#row_device_$block_id').remove();");
        $this->showMessage(_p('device_successfully_unblocked'));
    }

    public function unblockIp()
    {
        $block_id = $this->get('block_id');
        Single::get_object_block()->unblockIp($block_id);
        $this->call("$('#row_ip_$block_id').remove();");
        $this->showMessage(_p('ip_successfully_removed'));
    }

    public function blocked_ip_moderation()
    {
        Phpfox::isUser(true);
        $sMessage = '';
        switch ($this->get('action')) {
            case 'remove':
                foreach ((array)$this->get('item_moderate') as $iId) {
                    Single::get_object_block()->unblockIp($iId);
                }
                $sMessage = _p('ips_successfully_removed');
                break;
            case 'trust':
                foreach ((array)$this->get('item_moderate') as $iId) {
                    $hash_id = Single::get_object_block()->getHashId($iId);
                    //Trust this an IP
                    Single::get_object_trust()->trustIp($hash_id);
                    //Remove it from blocked ips list
                    Single::get_object_block()->unblockIp($iId);
                }
                $sMessage = _p('ips_successfully_trusted');
                break;
        }

        $this->alert($sMessage, _p('moderation'), 300, 150, true);
        $this->hide('.moderation_process');
        $this->call('setTimeout(function() {$Core.reloadPage();}, 1800);');
    }

    public function trusted_ip_moderation()
    {
        Phpfox::isUser(true);
        $sMessage = '';
        switch ($this->get('action')) {
            case 'remove':
                foreach ((array)$this->get('item_moderate') as $iId) {
                    Single::get_object_trust()->removeTrustIp($iId);
                }
                $sMessage = _p('ips_successfully_removed');
                break;
            case 'block':
                foreach ((array)$this->get('item_moderate') as $iId) {
                    Single::get_object_trust()->blockIpFromTrusted($iId);
                }
                $sMessage = _p('ips_successfully_blocked');
                break;
        }

        $this->alert($sMessage, _p('moderation'), 300, 150, true);
        $this->hide('.moderation_process');
        $this->call('setTimeout(function() {$Core.reloadPage();}, 1800);');
    }

    public function blocked_device_moderation()
    {
        Phpfox::isUser(true);
        $sMessage = '';
        switch ($this->get('action')) {
            case 'unblock':
                foreach ((array)$this->get('item_moderate') as $iId) {
                    Single::get_object_block()->unblockDevice($iId);
                }
                $sMessage = _p('devices_successfully_unblocked');
                break;
        }

        $this->alert($sMessage, _p('moderation'), 300, 150, true);
        $this->hide('.moderation_process');
        $this->call('setTimeout(function() {$Core.reloadPage();}, 1800);');
    }

    public function removeTrustIp()
    {
        $trusted_id = $this->get('trusted_id');
        Single::get_object_trust()->removeTrustIp($trusted_id);
        $this->call("$('#row_ip_$trusted_id').remove();");
        $this->showMessage(_p('ip_successfully_removed'));
    }

    public function blockIpFromTrusted()
    {
        $trusted_id = $this->get('trusted_id');
        if (Single::get_object_trust()->blockIpFromTrusted($trusted_id)) {
            $this->call("$('#row_ip_$trusted_id').remove();");
            $this->showMessage(_p('ip_successfully_blocked'));
        } else {
            $this->showMessage(_p('cant_block_this_ip'));
        }
    }
}
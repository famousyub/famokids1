# Single Device Login

## App Info

- `App name`: Single Device Login
- `Version`: 4.2.0
- `Link on Store`: https://store.phpfox.com/product/1656/single-device-login
- `Owner`: phpFox

## What's New in 4.2.0

- Allow users can trust Device.
- Allow users can trust/block IP.
- Update algorithm to check unique device.
- Support actions on warning message.
- Support link to view login session in notification email.
- Update layout.

## Installation Guide

Please follow below steps to install Single Device Login app:

1. Install the Single Device Login app from the store.

2. Clear cache on your site

Congratulation! You have completed installation process.
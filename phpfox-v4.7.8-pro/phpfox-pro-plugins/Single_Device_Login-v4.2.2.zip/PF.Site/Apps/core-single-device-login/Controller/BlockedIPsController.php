<?php

namespace Apps\phpFox_Single_Device_Login\Controller;

use Phpfox_Component;
use Phpfox;
use Apps\phpFox_Single_Device_Login\Service\Single;

defined('PHPFOX') or exit('NO DICE!');

/**
 * @author Neil J. <neil@phpfox.com>
 * Class BlockedIPsController
 * @package Apps\phpFox_Single_Device_Login\Controller
 */
class BlockedIPsController extends Phpfox_Component
{
    public function process()
    {
        //Redirect to home is not login
        if (!Phpfox::isUser()) {
            $this->url()->send('');
        }

        //set section menus
        $aMenu = Phpfox::getService('login-history')->getSectionMenu();


        $this->search()->set([
            'type' => 'blocked_ip',
            'field' => 'blocked_ip.blocked_id',
            'ignore_blocked' => true,
            'search_tool' => array(
                'table_alias' => 'blocked_ip',
                'no_filters' => [
                    _p('when'),
                    _p('sort'),
                ],
                'search' => array(
                    'action' => $this->url()->makeUrl('login-history.blocked-ips'),
                    'default_value' => _p('search_ip'),
                    'name' => 'search',
                    'field' => array('blocked_ip.blocked_info')
                ),
                'sort' => [
                    'latest' => array('blocked_ip.timestamp', '', 'desc'),
                    'recent' => array('blocked_ip.timestamp', '', 'asc'),
                    'ip_desc' => array('blocked_ip.blocked_info', '', 'desc'),
                    'ip_asc' => array('blocked_ip.blocked_info', '', 'asc'),
                ]
            )
        ]);

        $this->search()->browse()->setPagingMode(Phpfox::getParam('pagination'));

        $condition = $this->search()->getConditions();
        $aSearch = $this->request()->get('search');
        list($total_page, $aBlockedIps) = Single::get_object_block()->getBlockedIps($condition,
            $this->search()->getSort(),
            $this->search()->getPage());

        //Set Pager
        $this->search()->browse()->setPagingMode('pagination');
        $aParamsPager = array(
            'page' => $this->search()->getPage(),
            'size' => 7,
            'count' => $total_page,
            'paging_mode' => $this->search()->browse()->getPagingMode()
        );

        Phpfox::getLib('pager')->set($aParamsPager);

        //Set moderator actions
        $aModerationMenu = [
            [
                'phrase' => _p('remove'),
                'action' => 'remove'
            ],
            [
                'phrase' => _p('trust_ip'),
                'action' => 'trust'
            ],
        ];

        $this->setParam('global_moderation', [
            'name' => 'login-history',
            'ajax' => 'login-history.blocked_ip_moderation',
            'menu' => $aModerationMenu
        ]);

        //Set header and send variables to template
        $this->template()
            ->assign([
                'current'=> $this->request()->get('sort'),
                'aBlockedIps' => $aBlockedIps
            ])
            ->setTitle(_p('blocked_ips'))
            ->setBreadCrumb(_p('blocked_ips'), $this->url()->makeUrl('login-history.blocked-ips'))
            ->buildSectionMenu('login-history', $aMenu);
    }
}

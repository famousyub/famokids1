<?php

namespace Apps\phpFox_Single_Device_Login\Controller;

use Phpfox_Component;
use Phpfox;
use Apps\phpFox_Single_Device_Login\Service\Single;

defined('PHPFOX') or exit('NO DICE!');

/**
 * @author Neil J. <neil@phpfox.com>
 * Class HistoryController
 * @package Apps\phpFox_Single_Device_Login\Controller
 */
class HistoryController extends Phpfox_Component
{
    public function process()
    {
        //Redirect to home is not login
        if (!Phpfox::isUser()) {
            $this->url()->send('');
        }

        //get all current user hashes
        $all_hashes = Single::get_object_hash()->getAll();
        foreach ($all_hashes as $key => $all_hash) {
            if (Single::get_object_block()->isCurrentIp($all_hash['device_info']['ip'])) {
                $all_hashes[$key]['is_current_ip'] = true;
            } else {
                $all_hashes[$key]['is_current_ip'] = false;
            }
            if (Single::get_object_block()->isCurrentDevice($all_hash['device_info']['device_hash'])) {
                $all_hashes[$key]['is_current_device'] = true;
            } else {
                $all_hashes[$key]['is_current_device'] = false;
            }
        }

        $aMenu = Phpfox::getService('login-history')->getSectionMenu();

        //Set header and send variables to template
        $this->template()
            ->setTitle(_p('login_history'))
            ->setBreadCrumb(_p('login_history'), $this->url()->makeUrl('login-history'))
            ->assign([
                'all_hashes' => $all_hashes
            ])
            ->buildSectionMenu('login-history', $aMenu);
    }
}
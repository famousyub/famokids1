<?php

namespace Apps\phpFox_Single_Device_Login\Controller;

use Phpfox_Component;
use Phpfox;
use Apps\phpFox_Single_Device_Login\Service\Single;

defined('PHPFOX') or exit('NO DICE!');

/**
 * @author Neil J. <neil@phpfox.com>
 * Class TrustedIPsController
 * @package Apps\phpFox_Single_Device_Login\Controller
 */
class TrustedIPsController extends Phpfox_Component
{
    public function process()
    {
        //Redirect to home is not login
        if (!Phpfox::isUser()) {
            $this->url()->send('');
        }

        //set section menus
        $aMenu = Phpfox::getService('login-history')->getSectionMenu();

        //Set search params
        $this->search()->set([
            'type' => 'trusted_ip',
            'field' => 'trusted_ip.trusted_id',
            'ignore_blocked' => true,
            'search_tool' => array(
                'table_alias' => 'trusted_ip',
                'no_filters' => [
                    _p('when'),
                    _p('sort'),
                ],
                'search' => array(
                    'action' => $this->url()->makeUrl('login-history.trusted-ips'),
                    'default_value' => _p('search_ip'),
                    'name' => 'search',
                    'field' => array('trusted_ip.trusted_info')
                ),
                'sort' => [
                    'recent' => array('trusted_ip.timestamp', '', 'desc'),
                    'latest' => array('trusted_ip.timestamp', '', 'asc'),
                    'ip_desc' => array('trusted_ip.trusted_info', '', 'desc'),
                    'ip_asc' => array('trusted_ip.trusted_info', '', 'asc'),
                ]
            )
        ]);

        $this->search()->browse()->setPagingMode(Phpfox::getParam('pagination'));

        $condition = $this->search()->getConditions();
        list($total_page, $aTrustedIps) = Single::get_object_trust()->getTrustedIps($condition,
            $this->search()->getSort(),
            $this->search()->getPage());

        foreach ($aTrustedIps as $key => $aTrustedIp) {
            if (Single::get_object_block()->isCurrentIp($aTrustedIp['trusted_info'])) {
                $aTrustedIps[$key]['is_current'] = true;
            } else {
                $aTrustedIps[$key]['is_current'] = false;
            }
        }

        //Set Pager
        $this->search()->browse()->setPagingMode('pagination');
        $aParamsPager = array(
            'page' => $this->search()->getPage(),
            'size' => 7,
            'count' => $total_page,
            'paging_mode' => $this->search()->browse()->getPagingMode()
        );

        Phpfox::getLib('pager')->set($aParamsPager);

        //Set moderator actions
        $aModerationMenu = [
            [
                'phrase' => _p('remove'),
                'action' => 'remove'
            ],
            [
                'phrase' => _p('block_ip'),
                'action' => 'block'
            ],
        ];

        $this->setParam('global_moderation', [
            'name' => 'login-history',
            'ajax' => 'login-history.trusted_ip_moderation',
            'menu' => $aModerationMenu
        ]);

        //Set header and send variables to template
        $this->template()
            ->assign([
                'current'=> $this->request()->get('sort'),
                'aTrustedIps' => $aTrustedIps
            ])
            ->setTitle(_p('trusted_ips'))
            ->setBreadCrumb(_p('trusted_ips'), $this->url()->makeUrl('login-history.trusted_ips'))
            ->buildSectionMenu('login-history', $aMenu);
    }
}
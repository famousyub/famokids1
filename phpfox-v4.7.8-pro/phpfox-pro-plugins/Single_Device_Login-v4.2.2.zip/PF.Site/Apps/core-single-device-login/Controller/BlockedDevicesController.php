<?php

namespace Apps\phpFox_Single_Device_Login\Controller;

use Phpfox_Component;
use Phpfox;
use Apps\phpFox_Single_Device_Login\Service\Single;

defined('PHPFOX') or exit('NO DICE!');

/**
 * @author Neil J. <neil@phpfox.com>
 * Class BlockedDevicesController
 * @package Apps\phpFox_Single_Device_Login\Controller
 */
class BlockedDevicesController extends Phpfox_Component
{
    public function process()
    {
        //Redirect to home is not login
        if (!Phpfox::isUser()) {
            $this->url()->send('');
        }

        //set section menus
        $aMenu = Phpfox::getService('login-history')->getSectionMenu();


        $this->search()->set([
            'type' => 'blocked_device',
            'field' => 'blocked_device.blocked_id',
            'ignore_blocked' => true,
            'search_tool' => array(
                'table_alias' => 'blocked_device',
                'no_filters' => [
                    _p('when'),
                    _p('sort'),
                ],
                'search' => array(
                    'action' => $this->url()->makeUrl('login-history.blocked-devices'),
                    'default_value' => _p('search_devices'),
                    'name' => 'search',
                    'field' => array('sh.device_info')
                ),
                'sort' => [
                    'latest' => array('blocked_device.timestamp', '', 'desc'),
                    'recent' => array('blocked_device.timestamp', '', 'asc'),
                    'device_desc' => array('blocked_device.blocked_info', '', 'desc'),
                    'device_asc' => array('blocked_device.blocked_info', '', 'asc'),
                ]
            )
        ]);

        $this->search()->browse()->setPagingMode(Phpfox::getParam('pagination'));

        $condition = $this->search()->getConditions();
        list($total_page, $aBlockedDevices) = Single::get_object_block()->getBlockedDevices($condition,
            $this->search()->getSort(),
            $this->search()->getPage());

        //Set Pager
        $this->search()->browse()->setPagingMode('pagination');
        $aParamsPager = array(
            'page' => $this->search()->getPage(),
            'size' => 7,
            'count' => $total_page,
            'paging_mode' => $this->search()->browse()->getPagingMode()
        );

        Phpfox::getLib('pager')->set($aParamsPager);

        //Set moderator actions
        $aModerationMenu = [
            [
                'phrase' => _p('unblock'),
                'action' => 'unblock'
            ],
        ];

        $this->setParam('global_moderation', [
            'name' => 'login-history',
            'ajax' => 'login-history.blocked_device_moderation',
            'menu' => $aModerationMenu
        ]);

        //Set header and send variables to template
        $this->template()
            ->assign([
                'current' => $this->request()->get('sort'),
                'aBlockedDevices' => $aBlockedDevices
            ])
            ->setTitle(_p('blocked_devices'))
            ->setBreadCrumb(_p('blocked_devices'), $this->url()->makeUrl('login-history.blocked-devices'))
            ->buildSectionMenu('login-history', $aMenu);
    }
}
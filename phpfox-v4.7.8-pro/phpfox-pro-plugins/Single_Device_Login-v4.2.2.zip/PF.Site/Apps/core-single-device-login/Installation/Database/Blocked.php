<?php

namespace Apps\phpFox_Single_Device_Login\Installation\Database;

use \Core\App\Install\Database\Field as Field;
use \Core\App\Install\Database\Table as Table;


/**
 * Class Hash
 * @author Neil J. <neil@phpfox.com>
 * @package Apps\phpFox_Backup_Restore\Installation\Database
 */
class Blocked extends Table
{

    protected function setTableName()
    {
        $this->_table_name = 'single_blocked';
    }

    public function getTableName()
    {
        return $this->_table_name;
    }

    protected function setFieldParams()
    {
        $this->_aFieldParams = [
            'blocked_id' => [
                Field::FIELD_PARAM_TYPE => Field::TYPE_INT,
                Field::FIELD_PARAM_TYPE_VALUE => 11,
                Field::FIELD_PARAM_OTHER => 'UNSIGNED NOT NULL',
                Field::FIELD_PARAM_PRIMARY_KEY => true,
                Field::FIELD_PARAM_AUTO_INCREMENT => true
            ],
            'type' => [
                Field::FIELD_PARAM_TYPE => Field::TYPE_TINYINT,
                Field::FIELD_PARAM_TYPE_VALUE => 1,
            ],//1: device; 2: IP
            'user_id' => [
                Field::FIELD_PARAM_TYPE => Field::TYPE_INT,
                Field::FIELD_PARAM_TYPE_VALUE => 11
            ],
            'hash_id' => [
                Field::FIELD_PARAM_TYPE => Field::TYPE_INT,
                Field::FIELD_PARAM_TYPE_VALUE => 11
            ],
            //IP or device hash
            'blocked_info' => [
                Field::FIELD_PARAM_TYPE => Field::TYPE_VARCHAR,
                Field::FIELD_PARAM_TYPE_VALUE => 64
            ],
            'timestamp' => [
                Field::FIELD_PARAM_TYPE => Field::TYPE_INT,
                Field::FIELD_PARAM_TYPE_VALUE => 11
            ]
        ];
    }
}

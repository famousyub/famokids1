<?php
$aPluginFiles[] = 'PF.Base/module/forum/';
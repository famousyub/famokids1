<?php
defined('PHPFOX') or exit('NO DICE!');
?>
<div class="global_attachment">
    <div class="global_attachment_header">
        <ul class="global_attachment_list" data-id="{$id}"></ul>
    </div>
</div>

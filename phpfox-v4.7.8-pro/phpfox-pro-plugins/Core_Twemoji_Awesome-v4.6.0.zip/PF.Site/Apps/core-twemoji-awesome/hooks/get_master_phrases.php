<?php
$aOut[] = 'emoji';
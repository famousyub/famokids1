# phpFox Twemoji Awesome

Adding [Twemoji](http://twitter.github.io/twemoji/) support to phpFox.

## App Info

- `App name`: phpFox Twemoji Awesome
- `Version`: 4.6.0
- `Link on Store`: https://store.phpfox.com/product/1879/emoji
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Credits

* [Elle Kasai](https://github.com/ellekasai/twemoji-awesome)
* [Twitter](http://twitter.github.io/twemoji/)
* [linyows](https://github.com/linyows/jquery-emoji)

## Installation Guide

Please follow below steps to install new phpFox Twemoji Awesome app:

1. Give 777 permission for folder PF.Site/Apps/core-twemoji-awesome/.
2. Install the Twemoji Awesome app from the store.
3. Clear cache on your site

Congratulation! You have completed installation process.
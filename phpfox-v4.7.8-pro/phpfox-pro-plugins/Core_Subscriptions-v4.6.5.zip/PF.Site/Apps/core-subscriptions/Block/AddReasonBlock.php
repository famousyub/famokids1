<?php
namespace Apps\Core_Subscriptions\Block;

use Phpfox_Component;

defined('PHPFOX') or exit('NO DICE!');

class AddReasonBlock extends Phpfox_Component
{
    public function process()
    {

    }
}
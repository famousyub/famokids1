<?php
/**
 * [PHPFOX_HEADER]
 *
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		Raymond Benc
 * @package 		Phpfox
 * @version 		$Id: view.html.php 5382 2013-02-18 09:48:39Z Miguel_Espinoza $
 */

defined('PHPFOX') or exit('NO DICE!');

?>
{plugin call='subscribe.template_controller_view__1'}
<div class="main_break"></div>
{template file='subscribe.block.entry'}
{plugin call='subscribe.template_controller_view__2'}
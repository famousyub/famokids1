<?php
defined('PHPFOX') or exit('NO DICE!');

$bLoadUserField = true;
$sUserFieldSelect = 'uf.subscribe_id, ';
?>
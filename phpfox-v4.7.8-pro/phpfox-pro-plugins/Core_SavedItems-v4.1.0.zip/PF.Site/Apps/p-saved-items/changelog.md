# Saved Items :: Change Log

## Version 4.1.0

### Information

- **Release Date:** June 17, 2019
- **Best Compatibility:** phpFox >= 4.7.2

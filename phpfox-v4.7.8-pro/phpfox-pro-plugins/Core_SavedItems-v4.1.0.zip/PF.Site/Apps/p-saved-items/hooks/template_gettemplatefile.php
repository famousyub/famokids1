<?php
$savedItemSupportDetailTemplate = ['v.controller.play'];
if(in_array($sTemplate, $savedItemSupportDetailTemplate)) {
    $this->_aVars['bIsDetailPage'] = true;
}
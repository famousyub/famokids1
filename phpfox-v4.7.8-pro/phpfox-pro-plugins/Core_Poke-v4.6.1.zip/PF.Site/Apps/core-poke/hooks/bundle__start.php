<?php

$aBundleScripts[] = [
    'autoload.css' => 'app_core-poke',
];
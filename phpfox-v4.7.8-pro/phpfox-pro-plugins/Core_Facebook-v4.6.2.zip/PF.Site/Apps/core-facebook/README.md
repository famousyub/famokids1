# Facebook Connect

## App Info

- `App name`: Facebook Connect
- `Version`: 4.6.2
- `Link on Store`: https://store.phpfox.com/product/1897/facebook-connect
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install Facebook Connect app:

1. Give 777 permission for folder **PF.Site/Apps/core-facebook/**.

2. Install the Facebook Connect app from the store.

3. Clear cache on your site

Congratulation! You have completed installation process.
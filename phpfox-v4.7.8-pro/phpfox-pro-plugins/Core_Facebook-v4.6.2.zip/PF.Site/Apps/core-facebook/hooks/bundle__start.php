<?php

$aBundleScripts[] = [
    'autoload.css' => 'app_core-facebook',
    'autoload.js' => 'app_core-facebook',
];
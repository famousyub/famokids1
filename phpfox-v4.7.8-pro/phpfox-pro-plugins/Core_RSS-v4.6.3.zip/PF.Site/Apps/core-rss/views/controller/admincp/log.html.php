<?php 
defined('PHPFOX') or exit('NO DICE!');
?>
{module name='rss.log'}

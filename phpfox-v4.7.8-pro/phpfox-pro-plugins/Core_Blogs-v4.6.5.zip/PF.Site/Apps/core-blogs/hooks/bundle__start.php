<?php

$aBundleScripts[] = [
    'autoload.js' => 'app_core-blogs',
];
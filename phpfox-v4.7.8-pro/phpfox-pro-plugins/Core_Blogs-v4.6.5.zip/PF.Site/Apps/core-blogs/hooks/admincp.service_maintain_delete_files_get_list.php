<?php
defined('PHPFOX') or exit('NO DICE!');
$aPluginFiles[] = 'PF.Base/module/blog/';
$aPluginFiles[] = 'PF.Site/Apps/core-blogs/Block/PopularTopic.php';
$aPluginFiles[] = 'PF.Site/Apps/core-blogs/views/block/topic.html.php';
<?php 
defined('PHPFOX') or exit('NO DICE!');

?>
{if isset($aCategories)}
    {template file='core.block.category'}
{/if}
